# Governance changes

See [the detailed change log](governance-change-log.md) and [capability ledger](capability-registry.md).

REL-2026-09-10-02 adds optional closed MCP tooling; provider activation stays quarantined.

[Sentinel 01-1](../prompts-output/%5B01-1%5Dsentinel-implementacion-verificable.md) prepara
un candidato sin activar. Pruebas puras y separación de exportación/identidad; integración,
custodia, parada y rollback NO_VERIFICADOS. No es una nueva admisión ni release.
