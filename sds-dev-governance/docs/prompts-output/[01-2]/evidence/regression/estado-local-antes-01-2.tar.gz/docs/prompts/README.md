# Prompts del repositorio canónico

Fuentes y propuestas de trabajo; su presencia no activa controles ni autoriza su ejecución.
La convención y el ciclo de vida los define `practices/02-prompt-system.md` desde la raíz del kit.

## Sentinel — 12 de septiembre de 2026

- [Revisión adversarial recibida](SDS-REVISION-sentinel-perimetro-local-2026-09-12.md): archivo histórico del texto aportado por el usuario, sin corregir sus afirmaciones. No es un prompt de implementación ni evidencia obtenida en este Mac.
- [Prompt final revisado](%5B01-0-alpha%5Dsentinel-perimetro-local.md): propuesta para evaluación local y preparación de una implementación revisable. No ejecutada. Se inicia esta numeración en el directorio, que no existía al comenzar esta tarea.
- [Conclusiones, interrelaciones y verificación](../prompts-output/%5B01-0%5Dsentinel-revision-aterrizada.md): contraste con el repositorio y límites de las garantías.

El archivo original `SDS-PROMPT-sentinel-perimetro-local.md` al que alude la revisión no se encontró en este repositorio. El SHA-256 citado dentro del archivo histórico se atribuye a aquel adjunto; no se ha verificado y no identifica esta transcripción. Tampoco se dispone de la conversación anterior completa que cita H-16.

## Sentinel — 13 de septiembre de 2026

- [Encargo recibido, ejecución 01-1](%5B01-1%5Dsentinel-implementacion-verificable.md).
- [Resultado y límites de verificación](../prompts-output/%5B01-1%5Dsentinel-implementacion-verificable.md).

Los antecedentes se conservan. El nuevo candidato no está activado; integración con efectos
y rollback dependen de una barrera exterior independiente que no está acreditada en esta sesión.

No cargar esta colección en cada sesión ni copiarla a los adapters. El prompt operativo referencia el análisis cuando es necesario; el archivo histórico permanece disponible para auditoría.
