Revisión adversarial de SDS-PROMPT-sentinel-perimetro-local.md

Fecha de consulta: 12-09-2026. Dictamen: no ejecutar la implementación tal como está redactada.

Se revisa el adjunto; no se reescribe, implementa ni ejecuta. Este informe integra los requisitos de la conversación, la propuesta previa y las decisiones del documento de Claude mediante hallazgos y correcciones necesarias. No introduce una arquitectura sustitutiva.

Alcance de la evidencia

Verificado: lectura íntegra y comparación textual del archivo entregado. SHA-256: bf42edb4f8c4ee2d08f0f83fcdaccbfcc6ad2281e3c289861dbfdf89bb1a09c9.

Verificado: el entorno de esta revisión es Linux; shutil.which('codex') y shutil.which('claude') devolvieron None. Esto acredita ausencia en PATH aquí, no ausencia en el Mac del usuario.

Documentado: comportamiento descrito por las fuentes oficiales enlazadas. Son documentos vivos consultados en la fecha indicada; no equivalen a una versión instalada ni a pruebas en el proyecto.

Hipótesis: consecuencias operativas condicionadas, estimaciones de sesiones y comportamiento que depende del repositorio o del Mac no accesibles.

No se han ejecutado Fase 0, hooks, init.sh, tests, snapshots ni comandos de modificación del proyecto. Las pruebas propuestas al final están sin ejecutar. Todas las cadenas de consecuencias describen qué ocurriría si se cumplen sus condiciones, no incidentes observados.

Eje 1 — Mecánica real de los harness

[H-01] writable_roots no define por sí solo un perímetro exclusivo

Severidad: bloquea
Eje: 1
Decisión(es) afectada(s): D1, D3; §3, §4
Evidencia: la referencia oficial de Codex define sandbox_workspace_write.writable_roots como raíces adicionales; también expone exclusiones de /tmp y $TMPDIR. El adjunto solo enumera la raíz del proyecto y promete bloqueo de escritura exterior. La lista no demuestra el conjunto efectivo permitido. La ubicación TOML de la clave también importa: no está documentada como writable_roots de nivel superior.
Consecuencia si no se corrige: plantilla aparentemente correcta → temporales u otras raíces siguen escribibles → un PASS documental se interpreta como confinamiento exclusivo. Debe observarse el perímetro efectivo; no basta con que coincida una línea de configuración.
Estado: documentado. El resultado en el Mac queda pendiente.

[H-02] Codex sí documenta configuración por proyecto, pero su existencia no prueba que esté activa

Severidad: bloquea
Eje: 1
Decisión(es) afectada(s): D1, D3, D5; §3, Fase 1
Evidencia: Config basics documenta .codex/config.toml por proyecto/subcarpeta. La precedencia actual es CLI → proyecto confiable, más cercano al cwd → perfil → usuario → valores gestionados por defecto → sistema → defaults. Los proyectos no confiables omiten capas locales de configuración, hooks y reglas. El fallback a HOME no queda justificado simplemente por no observar un efecto.
Consecuencia si no se corrige: el archivo y su modo pasan el chequeo → una capa diferente determina la ejecución → el agente trabaja con otra política o modifica HOME innecesariamente.
Estado: documentado. No está probado que la versión instalada cargue la capa concreta.

[H-03] chmod 444 no demuestra que el agente sea incapaz de cambiar la protección

Severidad: bloquea
Eje: 1
Decisión(es) afectada(s): D9; §3, Fases 0–1
Evidencia: el adjunto propone comprobar solo-lectura y una fixture, pero no distingue denegación de escritura directa, cambio de modo y sustitución del archivo desde su directorio. La prueba reproducible P3 al final separa esos casos. Si el propietario conserva capacidad de cambiar permisos o reemplazar la entrada, 444 solo demuestra el estado inicial. Un bloqueo adicional nativo de .codex/ sería otra causa, que debe identificarse.
Consecuencia si no se corrige: falla una escritura directa → se declara protección del mecanismo → una sustitución o cambio de modo posible invalida esa conclusión; o el instalador legítimo queda bloqueado por un mecanismo distinto.
Estado: hipótesis sobre el entorno objetivo; la insuficiencia del criterio de prueba es verificable en el texto. No se afirma haber vencido el sandbox.

[H-04] La receta de Claude no establece el sandbox ni una garantía común para todas las herramientas

Severidad: bloquea
Eje: 1
Decisión(es) afectada(s): D1; §3, Fases 0–2
Evidencia: el sandbox de Claude Code confina Bash y sus hijos; otras herramientas y MCP tienen otra cobertura. §3 enumera permissions.deny, allow y hooks, pero no especifica activación ni configuración efectiva del sandbox. permissions.allow tampoco equivale automáticamente a cualquier granularidad de operación: permisos de edición pueden ampliar escritura del proceso.
Consecuencia si no se corrige: pasa un test del hook Bash → se informa de protección del harness completo → otro canal conserva un acceso diferente. Las pruebas de hijos y enlaces son pertinentes, pero no están realizadas.
Estado: documentado, más omisión textual verificada. No se presupone que el sandbox esté desactivado en el proyecto real.

[H-05] Las denegaciones permanentes hacen inoperantes las excepciones que el prompt promete

Severidad: bloquea
Eje: 1
Decisión(es) afectada(s): D2, D4, D5, D7; §3–5, Fase 2
Evidencia: en Claude Code, permisos, deny prevalece sobre ask y allow entre ámbitos. Un allow local más específico no vence una denegación coincidente. Además, exit 2 en PreToolUse bloquea; no abre por sí solo una aprobación. El adjunto manda denegar rm y a la vez permitir rm .sds-tmp/<id>/x.log. No define cómo consume una autorización posterior.
Consecuencia si no se corrige: operación legítima denegada → usuario aprueba → la misma denegación sigue aplicándose. El usuario acaba repitiendo autorizaciones o quitando la regla general. La contradicción de limpieza se materializa si el patrón abarca todo rm, como sugiere la lista mínima.
Estado: documentado. El patrón concreto aún no existe; no se presenta un test ficticio como ejecutado.

[H-06] El trap no convierte los fallos del harness en fail-closed

Severidad: bloquea
Eje: 1
Decisión(es) afectada(s): D2, D7
Evidencia: Claude Code: errores y timeouts de hooks distingue exit 2 de un hook que no arranca, otros errores sin decisión válida y timeout de un command hook PreToolUse. Estos últimos pueden continuar por el flujo normal de permisos. El trap no existe antes de arrancar el script ni evita que el harness lo termine por timeout. La documentación menciona cambios en v2.1.214 y v2.1.248; no conocemos la versión instalada.
Consecuencia si no se corrige: autotest correcto al inicio → hook deja de arrancar o expira → no hay decisión del guard → otra capa puede permitir la operación. El autotest de jq ausente cubre solo un tipo de fallo.
Estado: documentado. El sandbox puede seguir protegiendo accesos exteriores; lo que cae es la garantía atribuida al hook.

[H-07] Codex tiene hooks documentados; la receta no define su conexión y su protocolo no es idéntico

Severidad: bloquea
Eje: 1
Decisión(es) afectada(s): D2, D4, D7; §3, Fase 1
Evidencia: Hooks de Codex documenta PreToolUse para shell, apply_patch y MCP, con excepciones de cobertura. write_stdin sobre una sesión existente no vuelve a dispararlo. También documenta bloqueo con exit 2; permissionDecision: "ask" todavía no está soportado y puede causar error no bloqueante. §3 conecta PreToolUse para Claude, pero no concreta la conexión equivalente en Codex.
Consecuencia si no se corrige: se instala el script y pasa su test directo → Codex nunca lo llama, o se copia un protocolo incompatible → se declara una protección interna inexistente. El interrogante «hooks si existen» sobrevive como comprobación de versión, no como conclusión de que faltan.
Estado: documentado y omisión textual verificada.

[H-08] Aprobación nativa no garantiza aprobación humana ni coste exclusivamente local

Severidad: bloquea
Eje: 1
Decisión(es) afectada(s): D4, D5; §5
Evidencia: modos de Claude Code documenta un modo auto con clasificador y defaults dependientes de versión, interfaz y configuración; cita v2.1.228 para un cambio de default en macOS/Linux/WSL. La referencia de Codex separa approval_policy de approvals_reviewer. El adjunto no verifica quién decide realmente. En Claude, permisos, persistir una aprobación Bash y aprobar una edición no tienen idéntico ciclo de vida.
Consecuencia si no se corrige: se asume «me preguntará y guardará mi decisión» → decide otro mecanismo o el permiso dura solo la sesión → aparecen accesos que el usuario esperaba aprobar o preguntas repetidas.
Estado: documentado. No se presume que el usuario tenga activo un modo automático.

Eje 2 — Coste sistémico de tokens y turnos

[H-09] El ahorro local no resuelve una transición de aprobación sin salida

Severidad: degrada
Eje: 2
Decisión(es) afectada(s): D2, D4, D5, D7; §5
Evidencia: modelo hipotético siguiente, basado en las transiciones de H-05. No hay logs de dos horas, así que los recuentos son supuestos explícitos. Un diálogo nativo sobre una llamada pendiente puede costar cero turnos adicionales del modelo; un rechazo devuelto al modelo normalmente exige una continuación. No son la misma unidad.
Consecuencia si no se corrige: se optimizan milisegundos y dos líneas de stderr → se repiten razonamiento, solicitudes y comandos → el trabajo queda detenido aunque el hook sea rápido.
Estado: hipótesis, con cálculo reproducible.

Sesión ilustrativa de dos horas: 120 operaciones pretendidas: 112 ordinarias, 6 cambios internos legítimos para la tarea que coinciden con §4 y 2 accesos externos nuevos. Se supone ejecución secuencial, una llamada y su resultado cada vez. Los números no pretenden describir una sesión observada. Si se agrupan llamadas, una sola continuación puede procesar varios rechazos.

Comportamiento

Rechazos que devuelve el control

Interacciones y continuación

Agente informado que anticipa las seis restricciones

0 rechazos evitables

Dos aprobaciones externas, si hay pregunta humana efectiva. Las seis tareas internas requieren aclaración; no existe transición definida que garantice completarlas.

Agente que trabaja correctamente según el objetivo de libertad interna, pero descubre las seis restricciones al usarlas

6

Seis continuaciones procesan esos rechazos en el escenario secuencial. No todas son necesariamente adicionales al flujo exitoso. Preguntar, aprobar y reintentar no vence un deny vigente.

El mismo, con cuatro intentos externos erróneos añadidos

10

Cuatro continuaciones procesan los nuevos errores si corrige cada uno una vez. Si repite una vez cada una de las seis acciones internas tras aprobación ineficaz: 16 rechazos acumulados.

Para un bloqueo recuperable: el diálogo nativo puede suspender y reanudar la misma llamada sin continuación adicional del modelo; corregir una orden rechazada requiere una continuación que procese el error; preguntar y emitir luego una nueva llamada tras respuesta humana requiere dos continuaciones en ese recorrido. Son trayectorias, no medidas universales ni incrementos automáticos frente al éxito. El coste adicional se obtiene comparando preguntas, reintentos y contexto con una ejecución equivalente exitosa. Para un deny que permanece activo, ningún número finito de reintentos garantiza la reanudación.

Modelo de contexto incremental: Δtokens = política cargada + solicitudes/resultados visibles + continuaciones y reintentos + respuestas del usuario + avisos del harness. El tratamiento de caché y facturación depende del producto; no se puede convertir esta suma en euros ni en consumo real sin trazas. El cómputo local tiene coste de CPU/latencia; «gratis» solo puede referirse a no consumir inferencia por ejecutar ese script.

[H-10] Limitar líneas no limita tokens y la lectura inicial no tiene tamaño acotado

Severidad: degrada
Eje: 2
Decisión(es) afectada(s): D2; §0, §5
Evidencia: §5 limita a ocho líneas el núcleo y a dos el error, pero no su longitud. §0 obliga a leer scaffold/ completo sin conocer su tamaño. Es verificable que esos límites no fijan caracteres ni tokens. El coste concreto del scaffold es desconocido.
Consecuencia si no se corrige: crecerán plantillas o mensajes → seguirán cumpliendo la regla de líneas → aumentará el contexto de arranque o de cada rechazo sin que lo detecte el criterio. No puede afirmarse ahora que leer el scaffold sea caro.
Estado: verificado para la insuficiencia de la métrica; hipótesis para el coste futuro.

Eje 3 — Consecuencias a dos y tres saltos

[H-11] El ciclo de regeneración puede destruir permisos o dejar el control sin mantenimiento

Severidad: degrada
Eje: 3
Decisión(es) afectada(s): D5, D6, D9; §3, Fase 1
Evidencia: init.sh debe generar locales, volverlos de solo lectura y autotestearlos. No se especifica qué ocurre al repetirlo sobre permisos permanentes existentes, al actualizar ni al revocar con otras sesiones activas. Falta el init.sh real: su idempotencia no puede darse por rota ni por garantizada.
Consecuencia si no se corrige: segunda inicialización reemplaza excepciones o falla por permisos → el usuario cambia modos para terminar → una sesión posterior opera con excepciones perdidas o protección relajada. Alternativamente, una revocación seguida de reinicio de una sola sesión puede dejar otra con autorización anterior.
Estado: hipótesis. Debe comprobarse el ciclo real, no imponer otra plataforma.

[H-12] El arranque en otra carpeta o máquina puede cambiar qué política se lee

Severidad: degrada
Eje: 3
Decisión(es) afectada(s): D3, D5, D6, D11
Evidencia: Settings de Claude Code distingue origen de settings compartidas y locales; documenta cambios de ubicación de permisos persistidos en v2.1.211 y de fuentes tras /cd en v2.1.246. Un fichero ignorado por Git no aparece por clonar. El adjunto no determina cuál de sus raíces gobierna esas situaciones.
Consecuencia si no se corrige: nueva máquina o arranque desde subcarpeta → falta el local o se lee otra capa → solicitudes repetidas o controles diferentes → se conceden permisos más amplios para recuperar fluidez.
Estado: documentado en la mecánica; la cadena de reacción humana es hipótesis. No es un argumento para commitear rutas personales.

Eje 4 — Interrelaciones entre decisiones

[H-13] D9 prohíbe escrituras que D10 y la propia instalación necesitan

Severidad: bloquea
Eje: 4
Decisión(es) afectada(s): D9, D10; §3, Fase 1
Evidencia: D9 declara .git/ entero no escribible por el agente; D10 descarta su bloqueo completo. §3 exige que init.sh escriba en .codex/ y .claude/, también protegidos por D9. No se distingue bootstrap, actualización y operación, ni si la prohibición cubre manipulación directa o efectos de Git autorizado. D12 evita commit/push en esta tarea, pero no resuelve el funcionamiento posterior del scaffold.
Consecuencia si no se corrige: se aplica D9 literalmente → fallan mantenimiento y operaciones Git legítimas; se relaja implícitamente → deja de cumplirse el contrato de protección.
Estado: verificado por comparación textual. No se presupone qué excepciones ya tenga el repositorio.

[H-14] No usar parser es compatible con un detector limitado, no acredita las garantías de §4

Severidad: bloquea
Eje: 4
Decisión(es) afectada(s): D2, D7, D10; §4, Fase 2
Evidencia: detectar literalmente ls && rm no exige un parser general. Sin embargo, decidir destinos existentes y excepciones en cp, mv y redirecciones depende de argumentos, cwd, expansiones y enlaces. El documento no identifica un mecanismo nativo que resuelva esa semántica. El umbral del 70 % tampoco mide pérdida: una sustitución de igual tamaño puede destruir todo el contenido anterior. Son contraejemplos lógicos, no pruebas del hook inexistente.
Consecuencia si no se corrige: se pasan patrones de fixtures → se infiere que todo destructivo interno tiene gate → una vía no observada modifica datos dentro de una raíz escribible. D10 no añade recuperación; el adjunto tampoco demuestra una existente.
Estado: verificado respecto al salto lógico. Excluir snapshots no es por sí mismo un defecto y este hallazgo no exige añadirlos.

[H-15] D5 permite init.sh; su contradicción real está en el fallback a HOME

Severidad: degrada
Eje: 4
Decisión(es) afectada(s): D3, D5; §3
Evidencia: D5 dice expresamente «ni generador aparte de init.sh»: por tanto, no contradice que init.sh genere archivos. Sí prohíbe una carpeta en ~, mientras §3 manda aplicar un perfil en ~/.codex/config.toml si falla la configuración local. Tampoco concreta cómo seleccionar ese perfil ni obtener autorización para acceder fuera.
Consecuencia si no se corrige: fallo de carga interpretado como falta de soporte → se aplica fallback fuera del proyecto → se viola otra decisión cerrada o se modifica configuración compartida con más proyectos.
Estado: verificado para la contradicción textual. La necesidad del fallback no está acreditada.

[H-16] El adjunto sustituye requisitos del usuario por otros sin una decisión explícita

Severidad: bloquea
Eje: 4
Decisión(es) afectada(s): D3, D5; §0–1, §4, §8
Evidencia: en la conversación el usuario exigió control de búsqueda/lectura exterior, JSON de permisos permanentes dentro de SDS-Dev-Governance, libertad interna conservando controles existentes y uso de Graphify por el agente. El adjunto permite lectura exterior, elimina ese JSON, añade gates internos amplios y prohíbe Graphify. También cambia raíz por carpeta de configuración. No hay una autorización conversacional explícita que adopte esos cambios; aportar un texto para refutarlo no la concede.
Consecuencia si no se corrige: se implementa correctamente el adjunto → no se satisface el objetivo acordado → la lectura exterior continúa libre mientras aumenta la fricción interna.
Estado: verificado por comparación de la conversación y el adjunto. Corregir esta divergencia no amplía el alcance original.

[H-17] Fase 0 no puede ser literalmente sin escrituras y producir sus pruebas e informe

Severidad: bloquea
Eje: 4
Decisión(es) afectada(s): D7, D9; Fase 0 y Gate 1
Evidencia: la fase se denomina «sin escribir», pero exige producir un .md y probar chmod 444 con fixture. Crear y modificar la fixture son escrituras. El directorio autorizado de pruebas aparece en Fase 2, después de Gate 1.
Consecuencia si no se corrige: el agente cumple la prohibición → no consigue la evidencia exigida; o produce la evidencia → incumple la fase y puede necesitar una autorización tardía. No es necesario ejecutar nada para observar esta contradicción.
Estado: verificado. Antes de usar esa fase debe aclararse qué escrituras de evidencia están permitidas.

Eje 5 — Supuestos no declarados

[H-18] La receta presupone un entorno y un único origen de raíz que no ha verificado

Severidad: degrada
Eje: 5
Decisión(es) afectada(s): D1, D3–7, D9; §0, §3
Evidencia: el adjunto impone dos configuraciones, utilidades shell, detección por directorios de agente y rutas concretas del kit antes de inventariarlas. D3 funciona con un solo harness si la ubicación es inequívoca; no es falso simplemente por usar solo uno. Con ninguno o con varios marcadores a distintas profundidades, falta una regla única.
Consecuencia si no se corrige: un supuesto no se cumple → inicialización o detección erróneas → el usuario aplica una excepción manual → configuración y contrato divergen.
Estado: hipótesis sobre cada entorno; la falta de definición en esos casos está verificada.

Supuesto a comprobar

Si es falso, qué se rompe

Los dos harness están instalados y se usan

Un gate exige una configuración o prueba de un producto ausente; no puede obtenerse ese PASS.

Plataforma y versiones admiten las mismas opciones

Puede cargarse una opción distinta, ignorarse o fallar; Bash, permisos Unix y sintaxis de utilidades no son universales.

jq y el intérprete requerido están disponibles en el entorno real del hook

El parseo no arranca; el autotest de ausencia de jq no demuestra manejo de ausencia del intérprete ni timeout.

La raíz tiene un marcador .codex/ o .claude/ único

Sin marcador no se detecta; con varios no se sabe cuál fija el perímetro; el scaffold puede contener marcadores antes de inicializar.

Raíz Git, proyecto autorizado y fuente de settings coinciden

Worktrees, subdirectorios y proyectos sin Git pueden resolver ámbitos diferentes.

El agente y el usuario tienen identidades/permisos que permiten proteger el mecanismo

Si comparten autoridad sobre archivo y directorio, el modo 444 no acredita separación; si no, el instalador puede no poder mantenerlo.

init.sh no altera permisos existentes al repetirse

La regeneración puede borrar excepciones o requerir intervención; hay que leer su implementación.

Hay una sola sesión al revocar

Otra sesión puede conservar permisos hasta su propia actualización o reinicio; no hay revocación global demostrada.

El modo de aprobación es interactivo y humano

Automatización, política administrada o auto-review pueden denegar sin pregunta o decidir sin el usuario.

“Bloquear ejecución fuera” tiene un significado común

Ejecutar /usr/bin/git, arrancar con cwd exterior y ejecutar un script exterior son cosas distintas. Sin definirlo, pruebas y promesa no son comparables.

[H-19] Ignorar archivos no garantiza que las rutas personales queden fuera de Git

Severidad: degrada
Eje: 5
Decisión(es) afectada(s): D11; §3, §5, Fase 1
Evidencia: gitignore, manual 2.55.0 especifica que los archivos ya seguidos no quedan excluidos por añadirlos al ignore. El adjunto comprueba entradas de ignore y además manda declarar la raíz en AGENTS.md, sin precisar cómo evitar una ruta personal allí. Comprobación de solo lectura en el proyecto real: git ls-files -- .codex/config.toml .claude/settings.local.json; revisar el contenido generado para los archivos versionables. No se ha ejecutado sobre el repositorio del usuario.
Consecuencia si no se corrige: una configuración previamente seguida o una raíz absoluta entra en los archivos entregados → el chequeo de ignore pasa → una integración posterior incumple D11. D12 evita el commit ahora, no ese defecto del entregable.
Estado: documentado para el comportamiento de Git; la presencia de rutas en el índice o en archivos generados es una hipótesis pendiente.

Eje 6 — Rendimiento y fluidez

[H-20] El benchmark propuesto no separa el coste del guard ni verifica con qué frecuencia se paga

Severidad: degrada
Eje: 6
Decisión(es) afectada(s): D7; §5, Fase 1
Evidencia: §5 pide tiempos de cinco comandos, pero no comparación con/sin hook, repeticiones o aislamiento de costes. npm test puede dominar la medida. No se concreta quién llama a check-governance.sh al arrancar, cuántas veces ni si el autotest pasa por el mismo hook, lo que podría multiplicar invocaciones. No está disponible ese script para medir.
Consecuencia si no se corrige: el guard parece barato junto a una suite lenta → su coste repetido o su autotest pasan inadvertidos → las tareas cortas pierden fluidez. No se afirma que haya recursión; debe comprobarse la cadena de llamadas.
Estado: verificado para la limitación del diseño de medida; hipótesis para el coste real.

Lo medible después: latencia añadida por llamada, mediana y dispersión con el mismo entorno, número real de invocaciones, coste de arranque/autotest, mensajes y continuaciones tras rechazo. Solo es plausible ahora que una comprobación pequeña resulte barata. Como sensibilidad matemática, 120 invocaciones de 5/25/100 ms añaden 0,6/3/12 segundos de CPU/espera secuencial; esos tiempos unitarios no se han medido y no incluyen turnos del modelo ni espera del usuario.

Matriz de hechos del harness: qué sabemos y qué queda por demostrar

Las fuentes oficiales son vigentes en la fecha de consulta, sin atribuirles una versión local inexistente. Las versiones mínimas citadas son notas de esas páginas, no versiones instaladas.

Pregunta exigida

Respuesta de esta revisión

Prueba pendiente

¿Codex lee .codex/config.toml local?

Documentado: sí, condicionado por confianza y precedencia, H-02.

P2: efecto diferencial en el CLI instalado, desde raíz y subcarpeta.

¿Existen sandbox_mode, approval_policy, writable_roots?

Documentado: las dos primeras son claves principales; la tercera está bajo sandbox_workspace_write, H-01/H-08.

Confirmar schema/help de versión y configuración efectiva.

¿Codex respeta 444 como barrera?

Hipótesis: no existe prueba local; una denegación de escritura directa no demuestra inmutabilidad, H-03.

P3: escritura, chmod y reemplazo; distinguir causa del rechazo.

¿Codex tiene hooks pre-ejecución?

Documentado: sí, con límites y protocolo propios, H-07.

P4: hook activado, evento observado y efecto bloqueado en versión instalada.

¿Qué orden sigue Claude entre usuario/proyecto/local?

Documentado: gestionadas → CLI → local → proyecto → usuario para valores ordinarios; las listas de permisos se agregan y deny prevalece. Settings, H-05.

Mostrar fuentes con /status y /permissions, y probar conflicto con fixture.

¿Qué salida de hook bloquea Claude?

Documentado: exit 2 en PreToolUse; fallo de lanzamiento/timeout no equivale, H-06.

P4: ejecución real bajo cada condición, no solo invocar el script directamente.

¿Claude confina hijos y enlaces?

Documentado: hijos de Bash entran en su sandbox; no verificado el caso concreto de enlaces ni su cobertura en el Mac.

P5: proceso hijo y enlace dentro hacia destino de fixture exterior.

¿La excepción permanente persiste y conserva operación exacta?

No verificado: el adjunto presupone una equivalencia entre mecanismos, H-08.

P6: aprobar, nueva sesión, operación autorizada, operación no autorizada y revocación.

Comprobaciones reproducibles para una Fase 0 corregida — no ejecutadas

Estas comprobaciones concretan evidencia pedida por el usuario; no son instrucciones para implementar Sentinel. Requieren el entorno objetivo y autorización para fixtures. No se instala nada para suplir versiones ausentes.

P1. Identidad y superficie. Ejecutar individualmente, en el Mac objetivo:

command -v codex
codex --version
codex --help
command -v claude
claude --version
claude --help

En Claude, inspeccionar /status, /permissions y /sandbox según disponibilidad. Registrar interfaz, modo activo, origen de configuración y si la aprobación la presenta al humano. Estas inspecciones no cambian por sí mismas la prueba de comportamiento.

P2. Carga y precedencia de Codex. En un proyecto de fixture que el usuario haya declarado confiable: comparar una configuración local sandbox_mode = "read-only" con workspace-write mediante la misma creación inocua interna; mantener constantes flags y demás capas, y arrancar una sesión nueva en cada caso. Repetir desde una subcarpeta. Registrar comando exacto de lanzamiento, decisión de aprobación y existencia/contenido del destino. Sin escalación aprobada durante esa prueba. En esta revisión no se fija una sintaxis de lanzamiento no confirmada por el --help instalado.

P3. Protección 444. Sobre archivos de fixture, nunca sobre configuración real: propietario prepara tres archivos con modo 444. Dentro de la sesión y del sandbox real del agente, comparar por separado escritura directa, chmod u+w seguido de escritura y sustitución por otro archivo del mismo directorio. Repetir en carpeta ordinaria y en rutas protegidas de un proyecto desechable. Un rechazo debe registrar si proviene de permisos Unix, hook, ruta protegida nativa o sandbox.

Comandos de efectos a probar, con nombres exclusivos de fixture y ejecutados individualmente por el harness:

printf 'probe' > ./fixture-only/direct.txt
chmod u+w ./fixture-only/mode.txt
printf 'probe' > ./fixture-only/mode.txt
mv ./fixture-only/replacement.txt ./fixture-only/replace-target.txt

El propietario debe haber creado esos archivos y el replacement de prueba. Se registran permisos y contenidos antes y después. No se infiere nada sobre Codex de ejecutar estos comandos fuera de su sandbox.

P4. Hook realmente conectado. En una configuración desechable: contrastar exit 0 y exit 2, entrada inválida, dependencia ausente, script no ejecutable/no encontrado y timeout. Verificar que la llamada protegida dejó o no dejó su efecto inocuo. El autotest directo de shell solo valida el script; no el evento del harness. En Codex, comprobar además apply_patch y entrada posterior a una sesión shell persistente si ese canal se utiliza.

P5. Límite externo. Preparar con permiso una carpeta de pruebas que contenga proyecto y destino exterior. La autorización de preparación no debe ampliar el perfil restringido que se prueba. Probar lectura y escritura exteriores, escritura desde proceso hijo y mediante enlace interno hacia ese destino. Registrar el resultado en cada herramienta realmente usada. La prueba decide cobertura real; el hook de patrones no la sustituye.

P6. Ciclo de aprobación. Trazar permiso inexistente → pregunta humana → concesión puntual → fin de vigencia; y concesión permanente → archivo realmente actualizado → nueva sesión → uso permitido → operación distinta denegada → revocación → nueva sesión. Probar también que aprobar la limpieza temporal no exige retirar una denegación general. No basta comprobar un allow escrito a mano y un único caso positivo.

1. Lo que sobrevive a la revisión y por qué

D1 como principio, no como receta ya probada: el control efectivo del entorno es la capa adecuada para limitar accesos; un patrón shell no lo sustituye.

D2: evitar un parser propio y presentar el detector como limitado es proporcionado. La prueba literal ls && rm no contradice por sí sola esa decisión.

D5, parcialmente: separar plantillas compartidas de datos personales es coherente; init.sh está expresamente permitido como generador. No sobrevive la eliminación unilateral del JSON solicitado ni la equivalencia automática de permisos entre harness.

D8: el contenido no confiable no concede autoridad. No convierte al hook en inmunidad frente a inyección.

D10–D12, con la contradicción de .git resuelta: no añadir snapshots/stash automático, no commitear rutas personales y no hacer commit/push ni propagación reduce cambios ajenos al objetivo. D12 no contradice que una tabla describa qué archivos serán versionables después.

Tabla declarado/configurado/verificado, fixtures y silencio en éxito: permiten distinguir garantías reales y reducir ruido, siempre que las pruebas se ejecuten a través del harness correcto.

2. Lo que hay que cambiar antes de ejecutar, ordenado por severidad

Bloquea: reconciliar los requisitos del usuario con §1/D3/D5/§8 —lectura exterior, JSON, libertad interna y Graphify—; resolver la contradicción de escrituras en Fase 0. H-16/H-17.

Bloquea: definir la transición efectiva de aprobación y la excepción temporal sin chocar con deny o exit 2; verificar decisión humana y persistencia real. H-05/H-08.

Bloquea: corregir las garantías atribuidas a raíces adicionales, 444 y fail-closed; comprobar carga, conexión y cobertura por harness. H-01–H-04/H-06/H-07.

Bloquea: resolver D9/D10 y la autoridad de bootstrap/mantenimiento; no presentar el gate interno como completo a partir de patrones y tamaño. H-13/H-14.

Degrada: cerrar ciclo de reinicialización/revocación, raíz efectiva, fallback a HOME y exclusión real de rutas personales; medir arranque, rechazos y continuaciones, no solo cinco duraciones. H-09–H-12/H-15/H-18–H-20.

Estas correcciones señalan contradicciones y garantías no demostradas; no autorizan implementar una solución alternativa ni añadir requisitos ajenos al perímetro acordado.

3. Lo que solo puede saberse en Fase 0 y qué debe mirar el usuario

Versiones, superficie, modo y fuentes efectivos: buscar valores observados y origen de cada uno; una URL de documentación no es versión instalada.

Raíz y permisos efectivos: ver qué pasa desde raíz, subcarpeta y un proyecto con un solo harness; que consten temporales y canales fuera de Bash.

Protección del mecanismo: resultados distintos para escritura directa, chmod y reemplazo, con causa del rechazo; no aceptar únicamente ls -l o un hash.

Hook y autorización: una traza que muestre bloqueo, aprobación humana y continuación sin retirar una regla global; pruebas de hook ausente/timeout y del evento real.

Persistencia, revocación y mantenimiento: evidencia de nueva sesión y reinicialización sin perder permisos; leer el comportamiento real de init.sh y check-governance.sh antes de prometerlo.

Coste y cobertura: comparación controlada con/sin guard, número de invocaciones, reintentos y tareas que siguen bloqueadas. Un bloque desconocido debe quedar pendiente, nunca PASS por existencia del archivo.

Si solo pudiera cambiar una cosa, haría comprobable la transición «el usuario aprueba y la operación continúa con ese alcance», porque ahora la aprobación puede desembocar en la misma denegación indefinidamente.
