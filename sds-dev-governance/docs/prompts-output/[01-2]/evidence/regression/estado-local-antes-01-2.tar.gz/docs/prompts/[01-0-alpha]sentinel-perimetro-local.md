# [01-0-alpha] Sentinel: perímetro local verificable y de bajo coste en SDS

## PREFACE — NON-EXECUTABLE

Documento de preparación, 2026-09-12. Ejecutar desde `## Status` en adelante solo cuando el usuario invoque este prompt como tarea; guardarlo o revisarlo no lo activa.

- **Qué cambia:** sustituye la receta no demostrada por una evaluación local y un candidato acotado para el perímetro solicitado.
- **Por qué:** proteger accesos sin depender de la memoria del agente y sin convertir cada operación en una revisión del modelo.
- **Qué implica:** conservar libertad interna, controles SDS y permisos externos explícitos; comprobar quién aprueba y cómo continúa la operación.
- **Cómo:** preferir capacidades nativas verificadas, separar estado local de código distribuible y medir costes por categoría.
- **Consecuencias:** afecta potencialmente a bootstrap, identidad de copias, configuración de harness y ciclo de permisos. No se activa ni distribuye una política por escribir este archivo.
- **Severidad:** crítica si se permite al agente ampliar su propia autoridad o si un permiso se propaga a otro proyecto; severa si se anuncia un aislamiento inexistente. Taxonomía por referencia a `practices/14-phase-commit-report.md`.

Este prefacio no ahorra tokens si se carga junto con el prompt. La revisión histórica es evidencia consultable, nunca contexto obligatorio por operación.

## Status

**Propuesta final no ejecutada. LEVEL 3. Área: security; superficies: gobernanza, filesystem y configuración local.**

Objetivo: entregar el menor candidato revisable que permita trabajar con fluidez dentro del proyecto y controle búsqueda, lectura, escritura y efectos exteriores mediante mecanismos que el agente no pueda omitir. **El coste fijo debe ser el mínimo funcional: contenido compacto y procesamiento determinista mediante comandos Bash/procesos locales, no razonamiento por token.** Su ejecución autoriza investigación, fixtures y preparación local del candidato. No autoriza activar controles en esta sesión, modificar HOME o políticas administradas, otorgar nuevas admisiones, instalar herramientas, lanzar sesiones de inferencia de pago automáticamente, hacer commit/push ni propagar cambios a otros proyectos.

Completa todo lo independiente antes de pedir una decisión. No preguntes por elecciones de implementación reversibles incluidas en este alcance. Una aprobación pendiente no se infiere por silencio. Los resultados parciales de un harness no se presentan como protección común.

## 1. Contexto mínimo y fuentes

Resuelve `R` como raíz física del proyecto autorizado y `KIT` como raíz física del kit que lo gobierna. En este repositorio canónico, `R = KIT`; en un consumidor pueden ser diferentes. Usa parámetros explícitos y las fuentes SDS para identificarlos: ni el nombre de la carpeta ni el primer `.codex/`, `.claude/` o `.git` encontrado conceden autoridad. Una subcarpeta conserva su raíz autorizada; un repositorio hijo, worktree o hub independiente no hereda permisos por proximidad.

Desde `KIT`, carga `GOVERNANCE.md` → `practices/INDEX.md` → las prácticas seleccionadas y sus dependencias → `skills/README.md`; adapters y memorias solo si existen y aplican. No leas `scaffold/`, recursos, outputs o prácticas completos en bloque. Para autoría/preflight aplica 02/12/15; para implementación y verificación, amplía según el router.

Lee por función y con búsquedas dirigidas:

| Superficie | Punto real de integración |
|---|---|
| Bootstrap | `init.sh` delega en `scripts/bootstrap.py`; el metaprompt debe conservar equivalencia |
| Copias e identidad | `scripts/governance_tree.py`, `scripts/governance_copies.py`, sus tests y fila propietaria en `practices/RULE-COVERAGE.md` |
| Controles existentes | `check-governance.sh`, wrappers GitHub y `hooks/pre-push`; comprobar presencia no prueba instalación efectiva |
| Capacidades | `R/docs/governance/capability-registry.md`; admisión por revisión/modo, sin equivalencia con permisos de filesystem |
| Configuración generada | `adapters/`, `scaffold/` y consumidores exactos descubiertos; no crear una segunda fuente de reglas |

Antecedentes: [informe aterrizado](../prompts-output/%5B01-0%5Dsentinel-revision-aterrizada.md) y [revisión recibida](SDS-REVISION-sentinel-perimetro-local-2026-09-12.md). Consulta sus secciones necesarias, no las precargues en cada reanudación. El adjunto original citado por esa revisión no está disponible y su hash no está verificado aquí. Las decisiones D1–D12 no constituyen un contrato autónomo reconstruible desde sus citas.

Graphify se mantiene como descubrimiento auxiliar: usa una consulta acotada solo si existen grafo local, revisión y modo exactamente admitidos; aplica `skills/graphify.md`. Si no, registra una vez la causa y usa `RULE-COVERAGE.md` + `rg`. No lo instales, reconstruyas ni cargues por operación. MCP conserva sus rutas de control y ledger; no lo invoques para sustituir una denegación local. No realizar operaciones Hostinger.

## 2. Contrato que debe satisfacer el candidato

1. **Trabajo interno:** Sentinel no añade autorizaciones para lecturas, búsquedas, edición, refactors, tests y limpieza temporal normales ya autorizados dentro de `R`. Conserva las excepciones existentes sobre secretos, gobernanza, capacidades y operaciones Git/externas. No añade un veto general a `rm`, `mv`, `cp` o redirecciones ni un umbral de reducción de tamaño.
2. **Datos externos:** buscar nombres/listar, leer y modificar datos ajenos a `R` requieren alcance explícito vigente. Distingue esos datos de los ejecutables, librerías y archivos mínimos que el runtime necesita para funcionar. Inventaría esas excepciones; no llames «solo proyecto» a un permiso de lectura de `/` o de todo HOME.
3. **Ejecución y efectos:** distingue ruta del ejecutable, script interpretado, `cwd` y destinos reales. Ejecutar un binario del sistema no concede lectura general de documentos personales. Un comando con `cwd` interno tampoco concede red, un daemon exterior, credenciales, otro repo o un proveedor.
4. **Independencia del contexto:** la denegación debe mantenerse en el punto de acceso aunque falte el recordatorio del agente. Un hook omitible o un wrapper cuyo uso depende del agente no constituyen la frontera única. El lanzamiento normal, reanudación y canales activos deben quedar cubiertos o explícitamente fuera del candidato activable.
5. **Autoridad:** agente y proceso no pueden ampliar por sí mismos política, permisos ni verificador. Ubicación en proyecto, `chmod 444`, hash sin custodia o un campo `approved_by` no lo demuestran. Identifica quién mantiene la protección y cómo se actualiza sin dejarla abierta.
6. **Persistencia solicitada:** conserva un JSON local de permisos dentro de `KIT`, separado de plantillas, sin secretos y vinculado al proyecto. No sustituye al capability ledger ni a la configuración efectiva. Si el mecanismo disponible no puede consumirlo con autoridad verificable, entrega la limitación y el candidato documental; no simules permisos activos.
7. **Aprobación:** un consentimiento permite exactamente el alcance mostrado y una continuación real. No equivale a retirar una prohibición SDS existente. El actor humano se verifica; auto-review no se etiqueta como humano.
8. **Honestidad de cobertura:** `declarado`, `configurado`, `observado` y `no verificado` son campos distintos. Un archivo existente, una prueba directa del script o una prueba bajo un sandbox padre distinto nunca dan PASS de aislamiento del harness completo.

Son objetivos de esta propuesta; no reclasifican capacidades ni cambian reglas SDS activas al escribir el documento. Si aparece un conflicto material todavía no resuelto por estas instrucciones, documenta ambas autoridades y detén solo la mutación dependiente conforme a práctica 15.

## 3. Fase 0: viabilidad local y pruebas acotadas

La fase permite **escrituras de evidencia y fixtures**, no cambios en configuración real. Usa `R/docs/prompts-output/[01-0]/tmp/` y `evidence/`. Prepara proyecto de prueba y destino exterior como hermanos dentro de ese espacio. La sesión restringida que los prueba debe autorizar solo el proyecto de fixture; el permiso del preparador sobre la carpeta padre no forma parte del perfil ensayado.

No aproveches una autorización de preparación para escalar durante una prueba negativa. No cambies permisos de archivos reales. Si se necesita confianza de proyecto, una sesión interactiva o un canal humano aún no disponible, deja el caso pendiente y prepara su procedimiento exacto sin inventar resultados. No hagas llamadas al modelo en bucle para un benchmark local.

### 3.1 Identidad y política efectiva

Inventaría plataforma, interfaz, binarios y versiones mediante inspecciones acotadas. Observación histórica de esta revisión: Darwin, `codex-cli 0.154.0`, `Claude Code 2.1.269`; refrescar si cambia la revisión. No atribuyas la versión CLI al app-server que sirve una conversación sin identificarlo. No vuelques configuración completa, entorno ni transcripciones con posibles secretos.

Obtén las claves relevantes y su origen efectivo: confianza, precedencia, raíces adicionales, temporales, lectura exterior, mecanismos de aprobación y canales. No cambies configuración global para diagnosticar una capa local que parece ignorada.

Evalúa primero las primitivas nativas que evitan construir un mediador propio:

- **Codex:** perfiles de permisos con lectura externa restringida y excepciones mínimas; preservar protecciones heredadas y comprobar raíces/temporales efectivos. No mezclar por suposición perfiles actuales con la receta antigua `sandbox_workspace_write`. Punto de partida documental: [Permissions](https://learn.chatgpt.com/docs/permissions).
- **Claude:** comprobar sandbox Bash e hijos y controles de lectura de herramientas por separado; evaluar el ajuste documentado `permissions.blockReadsOutsideWorkingDirectories` y sus límites antes de diseñar reglas propias. Los permisos de herramientas y las listas filesystem del sandbox tienen semánticas diferentes. [Permissions](https://code.claude.com/docs/en/permissions), [Sandbox](https://code.claude.com/docs/en/sandboxing).

El ejemplo oficial es candidato, no prueba de soporte local. Un bloqueo permanente del harness puede no ser convertible en aprobación puntual; verificarlo antes de elegirlo. Si la granularidad nativa amplía lectura a escritura o una operación a todo un directorio, no traduzcas silenciosamente el permiso.

### 3.2 Casos y evidencia mínima

| Caso | Debe demostrar |
|---|---|
| T1 Configuración | Efecto diferencial con sesiones/configuraciones identificadas; raíz y subcarpeta; ausencia de capa local detectada |
| T2 Operación ordinaria | Lectura, búsqueda, edición, refactor y limpieza de archivos de prueba internos sin nuevas preguntas de Sentinel |
| T3 Límite exterior | Listado/búsqueda, lectura y escritura denegados sobre el destino de prueba sin permiso, por cada canal activo pertinente |
| T4 Indirecciones | Hijo, enlace a exterior, renombre/reemplazo y shell persistente; ningún canal permite lo que otro deniega |
| T5 Integridad | Intentos separados de escritura directa, chmod, sustitución y modificación del JSON/config/verificador de fixture; identificar la causa de rechazo |
| T6 Consentimiento | Sin permiso → pregunta humana → permiso puntual → efecto exacto → fin de vigencia; permiso permanente → nueva sesión → alcance exacto → revocación |
| T7 Fallos | Hook ausente/no ejecutable, dependencia ausente, entrada inválida y timeout; el límite crítico sigue vigente aunque el hook no decida |
| T8 Continuidad | Nueva sesión, reanudación sin historial de la regla, política cambiada y dos sesiones durante revocación; indicar cuándo se hace efectiva |

Crea marcadores inocuos en fixtures. Registra comando/tool, interfaz/versión, perfil, decisión y estado antes/después. No leer datos exteriores reales para demostrar que la lectura está permitida. No atribuir un rechazo del sandbox exterior de esta tarea a la política que ensayas dentro. Si T3–T8 no son demostrables, reporta el límite exacto y sigue con trabajo documental independiente.

## 4. Selección y preparación del candidato

Elige mecanismos nativos suficientes antes de añadir código. Cada componente adicional debe resolver una brecha concreta de T1–T8, indicar su frontera y demostrar que su fallo no concede más autoridad. Evita parser shell general, clasificador LLM, servicio residente, base de datos, snapshots/stash automático y sincronización bidireccional de permisos. Si una brecha exige cambiar ese alcance, presenta una propuesta pequeña con coste y consecuencia; no la implementes por inercia.

Un helper local para traducir estado solo es candidato si no se convierte en otra autoridad ni exige invocación voluntaria para proteger. Usa dependencias ya existentes cuando basten; Python stdlib ya forma parte del bootstrap. No es obligatorio introducir un hook si el runtime resuelve el caso.

### 4.1 JSON, aprobación y revocación

Ruta candidata, no creada por este documento: `KIT/.sds/local/sentinel/permissions.json`. Usa una única ubicación resuelta para este proyecto; no una lista global que transfiera permisos entre proyectos.

Especifica schema/version, identidad de proyecto, raíz física vinculada, generación de política y concesiones: ID, recurso, operación representable, alcance, duración, origen verificable de autorización y estado de revocación. No escribas supuestos de soporte como permisos concedidos. El runtime debe rechazar JSON manipulado, inválido, de otra raíz o de una revisión incompatible.

El JSON expresa concesiones autorizadas; las configuraciones por harness son proyecciones. Si no hay custodia que impida al agente autofirmar cambios, el JSON solo puede ser propuesta/inventario y la persistencia efectiva queda pendiente. Una respuesta de chat o una línea `approved_by` no se transforma por sí sola en autoridad técnica. No mantener dos archivos editables como fuentes equivalentes.

Transiciones exigidas:

| Estado / evento | Resultado |
|---|---|
| Operación dentro de alcance vigente | Continúa sin nueva revisión del modelo |
| Falta permiso concedible | Una solicitud con alcance visible; la llamada queda pendiente si el harness lo soporta |
| Concesión puntual | Aplicación al alcance aprobado; expiración comprobable; no conversión a permanente |
| Concesión permanente | Escritura por autoridad válida y lectura efectiva verificadas; reutilización en nueva sesión |
| Prohibición no concedible | Un rechazo claro, sin fingir que otra aprobación resolverá la misma prohibición |
| Rechazo repetido sin cambio | Mantener bloqueo; evitar nuevas solicitudes/continuaciones automáticas por la misma causa; no ocultar fallos de operaciones nuevas |
| Revocación o cambio de política | Invalidar autorización/caché dependiente; drenar/revalidar procesos y sesiones afectados antes de declarar revocación completa |

Si la aplicación solo puede hacerse al reiniciar, explica ese límite antes de conceder y revocar. No prometer revocación inmediata de descriptores ya abiertos ni procesos en marcha. No aprobar comandos amplios, intérpretes o shell completa como sustituto de un permiso sobre un archivo.

### 4.2 Bootstrap y distribución

Integra mediante el motor existente y un plan de escrituras. Conserva `--files-only`, `--dry-run`, preservación de originales y conflictos `.sds-new`. No hagas bootstrap directamente dentro del kit real: el motor lo rechaza. Prepara un kit de fixture separado de sus destinos. Excluye el propio árbol de fixtures antes de cualquier copia para evitar recursión.

**Condición previa al JSON real:** cerrar su exclusión en todas las rutas pertinentes. Hoy `snapshot(KIT)` en `scripts/governance_tree.py` no consulta `.gitignore`; `bootstrap.py` copia las entradas del inventario y `governance_copies.py` usa ese árbol para identidad. Guardar un permiso dentro del kit puede copiarlo y producir drift entre copias.

Diseña una exclusión estrecha del estado local reservado, manteniendo visibles código, políticas y cualquier modificación gobernante. Coordina distribución e identidad; no elimines toda una categoría del fingerprint para esconder divergencias. Prueba que el JSON no sale en bootstrap/exportación de kit, no cambia la identidad del código distribuible, no aparece en el índice Git y no se activa en una raíz diferente. No basta con `git check-ignore`.

Mantén referencias relativas/placeholders en archivos compartidos. No regeneres concesiones existentes. Prueba segunda inicialización, conflicto, actualización y revocación. No bloquees `.git/` de forma indiscriminada ni relajes sus protecciones existentes para pasar un test: diferencia operaciones Git admitidas y mantenimiento de controles. Para cambios efectivos de gobernanza sigue práctica 11 y su mapa de consumidores; no modifiques superficies sin delta.

## 5. Rendimiento: presupuesto incremental de Sentinel

Estas son metas iniciales de diseño y aceptación del candidato, no medidas ya obtenidas ni facturación estimada:

| Métrica | Criterio |
|---|---|
| Inferencia de autorización ordinaria | 0 llamadas LLM añadidas por Sentinel |
| Contexto por operación permitida | 0 bytes añadidos por Sentinel; verificar también avisos del harness |
| Contexto fijo adicional | Objetivo 0 bytes si la integración nativa basta; si hace falta router, objetivo ≤384 bytes UTF-8 y techo 512; conjunto SDS siempre leído ≤3.000 palabras sin subir el límite |
| Rechazo | Código/cause-ID + alcance + siguiente acción, ≤512 bytes de texto propio; detalle local bajo demanda, sin secretos |
| Trabajo interno | 0 rechazos/preguntas nuevos de Sentinel en T2 frente al baseline equivalente |
| Comprobación incremental local | Objetivo mediana ≤10 ms y p95 ≤25 ms por invocación; medir coste nativo y coste añadido por separado |
| Arranque incremental | Objetivo ≤250 ms para identidad/estado, con trabajo acotado; una suite de instalación no cuenta como arranque ordinario |
| Revalidación | Arranque y cambios relevantes; aplicar autorización siempre en el punto de acceso, sin repetir auditoría completa |

El conjunto fijo medido el 2026-09-12 ya ocupa 3.000 palabras: 1.449 kernel + 947 INDEX + 604 router de skills. Cualquier integración en ese conjunto requiere recuperar espacio con contenido equivalente y conservar sus obligaciones; no sumar el informe a los adapters.

Ese contador cubre esos tres archivos SDS; no mide todo el contexto del producto, herramientas o adapters. El límite es un máximo, no un objetivo que llenar. Inventaría también cualquier otra carga fija que añada el candidato.

Mide 100 pares con/sin comprobación tras calentamiento, sobre primitivas locales inocuas y la misma política de aislamiento. Registra entorno, revisión, tamaño de política, invocaciones y p50/p95. Si no puede aislarse la latencia nativa, decláralo. No uses `npm test` como cronómetro del guard ni `check-governance.sh` por llamada: ese validador crea temporales y ejecuta suites.

Un solo chequeo ligero por operación cuando haga falta; cachear únicamente decisiones/inventarios inmutables vinculados a versión y generación. No usar caché para conceder tras revocación. No hashear todo el repositorio ni leer todos los permisos en el contexto del modelo. Sin proceso residente por defecto: primero demostrar necesidad con mediciones.

Registra bytes y palabras por separado de tokens. Si hay tokenizer local adecuado ya instalado, mide tokens e identifica encoding; si no, deja tokens `NO MEDIDO`. Registra continuaciones/reintentos/avisos realmente observados; no conviertas 120 operaciones sintéticas en una factura. Si no se cumple un presupuesto, simplifica y vuelve a medir solo el componente cambiado; nunca debilites la frontera para mejorar un número.

### 5.1 Procesamiento local y salida mínima funcional

Esta sección incorpora la precisión del usuario del 2026-09-12: compactar lo cargado y trasladar procesamiento a ejecución Bash local. Compáctalo semánticamente; no envíes al modelo gzip, base64, prosa ofuscada ni abreviaturas opacas. El prompt de construcción y su análisis se cargan al trabajar en Sentinel, nunca como política fija de tareas ordinarias.

Resuelve localmente parseo/validación del JSON, comparación de revisiones, selección de entradas, clasificación determinista y medición. Bash orquesta; un proceso Python stdlib puede manejar JSON y rutas cuando reduzca complejidad. Nunca `eval`, `source` ni interpolación shell de datos de permisos, documentos o respuestas del modelo. Datos por stdin/archivo y argumentos separados.

No añadas una llamada de herramienta del modelo para «revisar Sentinel» antes de cada llamada de trabajo. Cuando sea necesario para seguridad, conecta la comprobación mediante el harness/punto de ejecución obligatorio y verificado. Si requiere el recuerdo del agente, no satisface la independencia del contexto.

En éxito, no emitir texto propio al modelo. Para diagnóstico solicitado, devolver estado, código y referencia de evidencia; detalle solo bajo demanda. Un chequeo con resultado incierto no se convierte en `OK` al compactarlo. Conserva evidencia acotada fuera del contexto sin registrar comandos completos, rutas personales o payloads sensibles por defecto.

Agrupa inspecciones locales independientes en una ejecución cuando reduzca llamadas, conservando resultado por operación. Una aprobación sobre un lote exige alcance finito visible y semántica definida; no ocultes más autoridad dentro del lote para ahorrar tokens. Reutiliza hechos bajo la misma revisión y generación; revalida únicamente lo invalidado.

Mide por separado el texto estático añadido, su presencia en solicitudes sucesivas, resultados de herramientas, avisos del harness y continuaciones. «Leído una vez» no significa «facturado una vez» si sigue en el contexto: caché de inferencia y cómputo local son magnitudes distintas.

## 6. Validación, activación y entrega

La implementación local del candidato solo continúa sobre las partes cuyo mecanismo y autoridad queden resueltos. Prepara código/configuración revisables en ubicaciones inactivas; no conectes hooks reales ni modifiques el perfil de esta sesión. No ejecutes automáticamente sesiones CLI que consuman inferencia para suplir pruebas ausentes. Completa primero schema, fixtures deterministas, diff, plan exacto de activación y procedimiento de reversión.

Para código ejecutable aplica práctica 16 y sus dependencias: verificación dirigida de frontera, bootstrap y copias; pruebas existentes solo donde haya delta/riesgo concreto. Nunca suites completas por cada paso ni PASS por existencia de archivos. Si no puedes ejecutar el sandbox/harness pertinente bajo el alcance autorizado, entrega las pruebas preparadas como `NOT VERIFIED`.

Criterios conjuntos para recomendar activación: T1–T8 pertinentes verdes, autoridad y aprobación humana probadas, persistencia exacta, no transferencia entre proyectos, ningún control SDS debilitado, trabajo ordinario fluido y presupuesto medido. Un harness ausente es `N/A`; uno presente pero no probado es `NOT VERIFIED`. No activar globalmente basándose en uno de ellos.

Entrega `R/docs/prompts-output/[01-0]prompt-output.md` siguiendo práctica 03 y un checkpoint breve: conclusión, matriz declarado/configurado/observado, cambios propuestos, riesgos interrelacionados, evidencia de rendimiento, comandos exactos probados, casos pendientes y plan de activación/reversión. El informe debe distinguir `VIABLE_VERIFICADO`, `CANDIDATO_NO_VERIFICADO` o `NO_VIABLE_EN_ESTE_MODO` por combinación interfaz/versión/política.

Al finalizar, presenta una sola decisión de activación sobre un resultado concreto si requiere autoridad nueva. No solicitar repetir autorizaciones vigentes. Si no hay un mecanismo suficiente dentro del alcance, concluye la evaluación con la brecha y el menor cambio necesario; no anunciar Sentinel implementado ni pedir al agente que «lo recuerde mejor».
