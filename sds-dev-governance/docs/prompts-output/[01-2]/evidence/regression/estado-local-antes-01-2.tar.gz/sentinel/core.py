"""Pure candidate helpers. No filesystem effects, command parsing or permission store."""
from dataclasses import dataclass
from collections import Counter
import hashlib
import json
from threading import Lock


REASONS = {
    'R1': 'escritura exterior', 'R2': 'ejecución de código externo',
    'R3': 'pérdida de contenido', 'R4': 'pérdida Git',
    'R5': 'alteración de control activo', 'R6': 'reintentos denegados',
    'R7': 'error de control', 'R8': 'capacidad no acreditada',
}


def object_label(label):
    """Escape a caller-sanitized label, not a payload, command or personal path."""
    if not isinstance(label, str) or not label or len(label) > 4096:
        raise ValueError('invalid object label')
    # ASCII JSON also neutralizes C0/C1, bidi overrides and terminal sequences.
    escaped = json.dumps(label, ensure_ascii=True)
    if len(escaped) <= 180:
        return escaped
    digest = hashlib.sha256(label.encode('utf-8')).hexdigest()[:16]
    # Re-encode the bounded original so no escape sequence is cut in half.
    prefix = label[:20]
    return json.dumps(prefix, ensure_ascii=True) + '…#' + digest


def message(reason, label, *, state='ACCIÓN_BLOQUEADA', transition='owner', partial=False):
    if reason not in REASONS:
        raise ValueError('unknown reason')
    if state not in {'ACCIÓN_BLOQUEADA', 'SOLICITUD_PENDIENTE',
                     'ERROR_DEL_CONTROL', 'LÍMITE_TÉCNICO'}:
        raise ValueError('state needs unavailable native stop evidence')
    if transition not in {'owner', 'native_approval'}:
        raise ValueError('unavailable transition')
    if transition == 'native_approval' and (reason in {'R5', 'R7', 'R8'}
                                           or state in {'ERROR_DEL_CONTROL', 'LÍMITE_TÉCNICO'}):
        raise ValueError('approval cannot override control policy or missing capability')
    next_step = ('No reintentes; usa la aprobación nativa para este efecto.'
                 if transition == 'native_approval' else
                 'No reintentes; el responsable debe revisar este caso y su control.')
    if state == 'SOLICITUD_PENDIENTE':
        next_step = 'Espera la decisión nativa pendiente; no vuelvas a solicitarla.'
    result = f'SENTINEL[{reason}] {state}: {REASONS[reason]} sobre {object_label(label)}. {next_step}'
    if partial:
        result += ' Hubo efectos parciales previos.'
    return result


def native_reply(harness, payload, *, deny=False, reason='R3', label='objeto no resuelto'):
    """Encode only. Never interpret tool_input or derive authority from native payloads.

    No handler is installed. Version-bound native delivery remains unverified.
    """
    events = {'claude': 'PreToolUse', 'codex': 'PreToolUse', 'gemini': 'BeforeTool'}
    if harness not in events or not isinstance(payload, dict):
        raise ValueError('unsupported harness or payload')
    if (payload.get('hook_event_name') != events[harness]
            or not isinstance(payload.get('tool_name'), str)
            or not payload['tool_name'] or not isinstance(payload.get('tool_input'), dict)):
        raise ValueError('unsupported native event or tool shape')
    if not deny:
        return ''  # No allow decision: normal native controls still apply.
    text = message(reason, label)
    if harness == 'gemini':
        response = {'decision': 'deny', 'reason': text}
    else:
        response = {'hookSpecificOutput': {'hookEventName': 'PreToolUse',
                    'permissionDecision': 'deny', 'permissionDecisionReason': text}}
    return json.dumps(response, ensure_ascii=True, separators=(',', ':'))


def canonical_object(value):
    """Validate an observer's canonical POSIX identity. No realpath/confinement claim."""
    if value is None:
        return None
    if (not isinstance(value, str) or not value.startswith('/')
            or len(value) > 4096 or '\x00' in value):
        raise ValueError('expected normalized object identity')
    parts = value.split('/')[1:]
    if value != '/' and any(p in {'', '.', '..'} for p in parts):
        raise ValueError('observer must resolve components before counting')
    return value


@dataclass(frozen=True)
class Denial:
    session: str | None
    turn: str | None
    invocation: str | None
    rule: str
    effect: str
    object_id: str | None
    repository: str | None = None
    decision: str = 'denied'


class RetryCounter:
    """One observer process; bounded RAM; no cross-process or tamper-resistant custody."""
    def __init__(self, limit=4096):
        if type(limit) is not int or not 1 <= limit <= 4096:
            raise ValueError('invalid state bound')
        self.limit = limit
        self._seen = set()
        self._cases = Counter()
        self._turns = Counter()
        self._lock = Lock()

    def observe(self, event):
        if event.decision not in {'denied', 'pending', 'allowed'}:
            raise ValueError('not a native decision')
        if event.rule not in REASONS or event.effect not in {
                'write', 'execute', 'loss', 'git-loss', 'control-change'}:
            raise ValueError('unknown rule or effect')
        obj = canonical_object(event.object_id)
        repo = canonical_object(event.repository)
        for item in (event.session, event.turn, event.invocation):
            if item is not None and (not isinstance(item, str) or not item or len(item) > 256):
                raise ValueError('invalid native identifier')
        if event.rule == 'R4' and repo is None:
            obj = None  # Do not merge Git objects from unidentified repositories.
        if event.decision != 'denied':
            return {'counted': False, 'threshold': False, 'state': event.decision}
        if event.session is None or event.invocation is None:
            return {'counted': False, 'threshold': None, 'state': 'LÍMITE_TÉCNICO'}
        identity = (event.session, event.invocation)
        case = (event.session, event.rule, event.effect, repo, obj) if obj is not None else None
        turn = (event.session, event.turn) if event.turn is not None else None
        with self._lock:
            if identity in self._seen:
                return {'counted': False, 'threshold': None, 'state': 'duplicate'}
            if len(self._seen) >= self.limit:
                return {'counted': False, 'threshold': None, 'state': 'ERROR_DEL_CONTROL'}
            self._seen.add(identity)
            if case is not None:
                self._cases[case] += 1
            if turn is not None:
                self._turns[turn] += 1
            per_case = self._cases[case] if case is not None else None
            per_turn = self._turns[turn] if turn is not None else None
            reached = (per_case is not None and per_case >= 2) or (per_turn is not None and per_turn >= 3)
            return {'counted': True, 'case_denials': per_case, 'turn_denials': per_turn,
                    'threshold': reached, 'native_stop': None,
                    'state': 'LÍMITE_TÉCNICO' if reached or case is None or turn is None else 'ACCIÓN_BLOQUEADA'}


def prevention_outcome(*, attempted, unauthorized_effect, native_pre_effect_block,
                       final_integrity, outer_contained):
    """Attribution gate: integrity or exterior containment never proves prevention."""
    for value in (attempted, unauthorized_effect, native_pre_effect_block,
                  final_integrity, outer_contained):
        if value is not None and type(value) is not bool:
            raise ValueError('evidence must be boolean or unknown')
    if unauthorized_effect is True:
        return 'FAIL'
    if (attempted is True and native_pre_effect_block is True
            and unauthorized_effect is False and final_integrity is True):
        return 'PASS'
    return 'NO_VERIFICADO'
