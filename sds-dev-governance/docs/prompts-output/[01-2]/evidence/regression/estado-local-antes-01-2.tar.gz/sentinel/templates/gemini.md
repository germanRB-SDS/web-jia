# Gemini — DECLARADO

No se encontró Gemini en PATH. No hay versión objetivo verificada ni plantilla ejecutable.
Descubrir primero sandbox, trust, políticas y ámbitos nativos de la instalación real.
No copiar settings de Claude ni asumir que el directorio de políticas de usuario es local.
La documentación actual distingue BeforeTool/AfterTool; su traducción de denegación está
preparada en el códec puro, pero no conectada ni probada en Gemini.
