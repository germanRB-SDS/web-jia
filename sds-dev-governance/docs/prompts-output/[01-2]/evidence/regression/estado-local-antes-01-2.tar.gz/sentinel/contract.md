# Sentinel — contrato candidato, sin activar

Propietario del encargo: usuario de `[01-1]`; incorporación 2026-09-13.
Ámbito: fuente de desarrollo del kit, plantillas y pruebas puras. No es política instalada.
La especificación completa es `docs/prompts/[01-1]sentinel-implementacion-verificable.md`.
Refina los antecedentes `[01-0]`; las restricciones activas de la sesión prevalecen.
No autoriza cambios en HOME, controles administrados, consumidores ni metadatos Git reales.
Las excepciones expresas al workflow de prácticas 05/14 son no branch/fetch/stash/commit/push.

## Intención y razones

| Código | Efecto | Tratamiento requerido |
|---|---|---|
| R1 | escritura exterior | Aprobación concreta para objeto/efectos; nunca ampliar R con cwd |
| R2 | ejecución de código externo | Autorización suficiente; runtime instalado no autoriza scripts arbitrarios |
| R3 | pérdida de contenido | Permitir solo efectos autorizados; tracked/untracked/ignored son equivalentes |
| R4 | pérdida Git | Identificar repositorio, referencias, index y trabajo; aprobación suficiente |
| R5 | alteración de control activo | Denegar autoautorización; intervención del responsable del control |
| R6 | límite de reintentos | Segundo del mismo caso en sesión o tercero agregado en turno; no reintentar |
| R7 | error de control | No convertir un fallo en permiso; conservar la restricción nativa |
| R8 | capacidad no acreditada | Mantener pendiente el control y su activación |

Crear/editar para la tarea dentro de R y limpiar artefactos propios comprobados conserva
autonomía ordinaria. Lectura/búsqueda/listado no añaden preguntas. R se fija por autoridad al
iniciar sesión. KIT es ubicación de fuente, LAB es área exclusiva nueva: ninguno amplía R.
Mover/reemplazar requiere cubrir origen, destino y pérdidas; una cadena puede dejar efectos
parciales. Lecturas, manifiestos y evidencia jamás son fuentes de permisos.

No existe un resolvedor general de efectos de shell en este candidato. Por ello no se instala
un hook que pretenda decidir sobre intérpretes, subcomandos o entradas de procesos abiertos.
Los códecs reciben payloads nativos de ensayo y una decisión ya establecida por un llamador
de confianza; no descubren autorización ni prueban la decisión del harness. Solo implementan
el subconjunto que nunca concede permisos: pasar al control nativo o denegar. Una solicitud
pendiente se deja al mecanismo de consentimiento nativo; el códec no emite ask ni allow.

## Estado y reintentos

`RetryCounter` es una referencia en memoria para un observador único, sin persistencia ni
registro de permisos. Cuenta denegaciones confirmadas, deduplica por sesión/invocación y usa
sesión/regla/efecto/repositorio/objeto como caso. La normalización recibida debe proceder de un
observador fiable; validar componentes no resuelve enlaces ni conserva confinamiento.
Si falta objeto, solo cuenta agregado. Si falta sesión/invocación no cuenta con precisión;
si falta turno conserva caso pero no inventa un turno a partir de reloj. Un Lock hace atómica
la actualización dentro del proceso; NO entre procesos de hooks. El tamaño es acotado; al
agotarse devuelve ERROR_DEL_CONTROL sin expulsar historia para fingir un contador nuevo.

Un evento pendiente/permitido no cuenta y no borra denegaciones anteriores. La autorización
nueva pertenece al mecanismo nativo; no se bloquea una llamada autorizada por un contador
histórico. Cambiar condición legítimamente requiere que el observador vuelva a acreditarla;
el contador no concede permiso. Reiniciar este objeto pierde estado: no resiste manipulación,
no conserva negativas entre sesiones y no está conectado a ningún bucle de agente.

## Mensajes y evidencia

Estados distintos: SOLICITUD_PENDIENTE, ACCIÓN_BLOQUEADA, TURNO_DETENIDO,
ERROR_DEL_CONTROL, LÍMITE_TÉCNICO. El código de este candidato NO emite TURNO_DETENIDO:
ningún adaptador acredita esa parada. Los nombres se escapan, acotan e identifican con digest
si hay truncado; el observador debe omitir secretos antes de entregar la etiqueta mínima.
El mensaje usa código, efecto, objeto y transición concreta; R5 nunca promete aprobación
como forma de superar una política superior. Éxito significa deferir sin texto adicional.

Un registro mínimo incluye los campos de §9 del prompt y conserva null como desconocido.
Resultados: PASS, FAIL, NO_VERIFICADO, NO_APLICA; no son estados de despliegue.
La capa exterior que rescata un escape no puede producir PASS de Sentinel. Integridad final
sin evento fiable no prueba bloqueo previo. El test puro mide función/serialización, no
consentimiento humano, canal visible real, fin de procesos ni consumo de la sesión.
