# Sentinel — candidato sin activar

Contrato: [contract.md](contract.md). Encargo: `[01-1]`. Cero dependencias nuevas.
Fuente editable, códecs puros y plantillas nativas; no hay hooks instalados ni nueva base de
permisos. El candidato NO acredita prevención general de pérdidas internas ni parada del agente.

- [Codex](templates/codex-config.toml): esquema 0.154.0, workspace-write/on-request/user,
  sin reglas allow, red desactivada y sin temporales exteriores por defecto. Fragmento de
  configuración; no mezclar con `default_permissions`/`permissions` ni perfil incompatible.
- [Claude](templates/claude-settings.json): sandbox requerido y sin reintento no aislado.
  `excludedCommands: []` no elimina exclusiones heredadas de otros ámbitos. Revisar composición.
  `filesystem.disabled` requiere revisión en fuentes que pueden configurarlo; no se presenta
  como control local de proyecto. Herramientas Write/Edit requieren comprobación independiente.
- [Gemini](templates/gemini.md): DECLARADO, sin plantilla ejecutable al faltar versión instalada.

Las versiones indicadas proceden de instalación y fuentes oficiales, no de integración viva.
Las plantillas están en una ubicación que los harness no cargan como settings.
No activar hasta cumplir el informe y todos los criterios del prompt.

## Uso de desarrollo

Desde KIT, `python3 -B tests/test-sentinel.py` ejecuta funciones puras; no lanza harness,
shell evaluada, fixtures destructivas, red ni modelo. `python3 -B sentinel/lab.py plan`
devuelve el plan congelado. `python3 -B sentinel/lab.py integration` termina con código 78:
la barrera y el backend de integración no están acreditados. No existe flag para saltarlo.

El runner es preparación limitada, no un supervisor general. W_A/W_B/W_E y A2 quedan
pendientes del entorno exterior provisionado. El informe usa staging de evidencia en
`docs/prompts-output/[01-1]/evidence/`, sin presentarlo como worktree o custodia independiente.

## Distribución y custodia

Bootstrap utiliza `snapshot(..., distribution=True)`: omite únicamente configuraciones
nativas personales identificadas por ruta exacta. `inventory` conserva esos archivos en
identidad porque pueden contener controles de seguridad, además de aprobaciones. Se acepta
que una diferencia personal pueda exigir revisión de fingerprint; ocultarla también ocultaría
controles. No hay filtro semántico de permisos ni exclusión general de `.codex`/`.claude`.
Solo `docs/prompts-output/[NN-R]/evidence` y `tmp` quedan fuera de ambas vistas por ser
resultados locales. Los informes, contratos, plantillas, hooks y reglas siguen detectándose.
No alojar controles cargables en áreas de evidencia; no convertir resultados en autoridad.
Un kit destino con configuración propia se conserva; bootstrap puede rechazar equivalencia
en vez de reconciliar permisos. No hay instalación ni propagación automática del candidato.

Git ignore y digest no ofrecen custodia frente al mismo usuario. El contador es RAM de un
observador, sin persistencia, y requiere custodia exterior para cualquier uso operativo.
