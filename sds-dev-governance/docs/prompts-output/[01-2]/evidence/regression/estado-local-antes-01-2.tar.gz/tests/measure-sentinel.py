"""Pure, bounded observations to stdout. Never executes payloads or changes fixtures."""
import ast
import hashlib
import json
from pathlib import Path
import platform
import statistics
import sys
import time

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT/'scripts'))
from governance_tree import included_path
from sentinel.core import message, native_reply


def observe():
    # Read as DATA only; never import/exec the archived baseline source.
    baseline = ROOT/'docs/prompts-output/[01-1]/evidence/baseline-governance_tree.py.txt'
    tree = ast.parse(baseline.read_text())
    ignores = next(ast.literal_eval(node.value) for node in tree.body
                   if isinstance(node, ast.Assign)
                   and any(isinstance(t, ast.Name) and t.id == 'IGNORED' for t in node.targets))
    def baseline_selection(path):
        # Reviewed baseline visit() skips those components and no other path classes.
        # This times its selection semantics, not the original filesystem traversal.
        return not any(part in ignores for part in path.split('/'))

    paths = ('.codex/config.toml', '.claude/settings.local.json', '.gemini/settings.json',
             '.codex/rules/safety.rules', '.claude/settings.json', '.gemini/policies/safety.toml',
             'sentinel/core.py', 'docs/prompts-output/[01-1]/report.md',
             'docs/prompts-output/[01-1]/evidence/raw.json',
             'docs/prompts-output/[01-1]/tmp/memo.md')
    personal = set(paths[:3])
    legitimate = set(paths[3:8])
    candidate = lambda path: included_path(path, distribution=True)
    functions = {'A': baseline_selection, 'B': candidate}
    # Frozen sample/criterion; warm-up separate and not counted as a measured pair.
    for function in functions.values():
        for path in paths:
            function(path)
    code_digest = {arm: hashlib.sha256(path.read_bytes()).hexdigest() for arm,path in
                   [('A', baseline), ('B', ROOT/'scripts/governance_tree.py')]}
    rows = []
    for pair in range(5):
        order = ['A', 'B'] if pair % 2 == 0 else ['B', 'A']
        for arm in order:
            start = time.perf_counter_ns()
            selected = [p for p in paths if functions[arm](p)]
            elapsed = (time.perf_counter_ns() - start) / 1_000_000
            rows.append({'run_id': f'pure-selection-{pair}-{arm}', 'pair_id': f'pair-{pair}',
                         'case_id': 'distribution-path-selection', 'arm': arm, 'phase': 'pure',
                         'order': order, 'harness_version': None, 'os': platform.platform(),
                         'code_digest': code_digest[arm], 'config_digest': None,
                         'fixture_seed': 'memory-paths-v1', 'initial_state_id': 'memory-paths-v1',
                         'expected_decision': 'exclude personal and evidence; preserve control sources',
                         'actual_decision': selected, 'deciding_layer': 'pure-path-classifier',
                         'tool_call_id': None, 'attempt_observed': False, 'effect_observed': None,
                         'pre_state_id': 'memory-paths-v1', 'post_state_id': None,
                         'rollback_state_id': None, 'elapsed_ms': elapsed, 'prompts': 0,
                         'retries': 0, 'model_calls': 0, 'message_evidence_ids': [],
                         'token_usage_reported': None, 'token_text_estimate': None,
                         'personal_selected': len(personal.intersection(selected)),
                         'legitimate_selected': len(legitimate.intersection(selected)),
                         'measurement_method': 'perf_counter_ns; selection only, ten in-memory paths',
                         'outcome': 'PASS' if set(selected) == legitimate else 'FAIL',
                         'limitation': 'Not bootstrap, sandbox, native integration or rollback evidence',
                         'evidence_ids': ['E01-baseline', 'E05-pure-measurements']})
    samples = {a: [r['elapsed_ms'] for r in rows if r['arm'] == a] for a in ('A', 'B')}
    stats = {a: {'median': statistics.median(v), 'min': min(v), 'max': max(v)} for a,v in samples.items()}
    delta = [next(r['elapsed_ms'] for r in rows if r['pair_id'] == f'pair-{i}' and r['arm'] == 'B')
             - next(r['elapsed_ms'] for r in rows if r['pair_id'] == f'pair-{i}' and r['arm'] == 'A')
             for i in range(5)]
    messages = []
    for h in ('codex', 'claude', 'gemini'):
        for i, (reason, label) in enumerate([('R3','fixtures/legacy'), ('R5','settings'),
                                             ('R3','fixtures/a\n\x1b[2J\u202eevil')]):
            payload = {'hook_event_name': 'BeforeTool' if h == 'gemini' else 'PreToolUse',
                       'tool_name': 'run_shell_command' if h == 'gemini' else 'Bash',
                       'tool_input': {'command': 'SYNTHETIC_SECRET'}}
            wire = native_reply(h, payload, deny=True, reason=reason, label=label)
            text = message(reason, label)
            wire_data = json.loads(wire)
            delivered = (wire_data['reason'] if h == 'gemini' else
                         wire_data['hookSpecificOutput']['permissionDecisionReason'])
            decoded_label, _ = json.JSONDecoder().raw_decode(delivered.split(' sobre ', 1)[1])
            messages.append({'evidence_id': f'message-{h}-{i}', 'harness': h,
                             'source': 'synthetic codec; no real hook delivery', 'text': text,
                             'wire': wire, 'chars': len(text), 'utf8_bytes': len(text.encode()),
                             'wire_utf8_bytes': len(wire.encode()),
                             'token_text_estimate': None, 'token_class': 'NO_DISPONIBLE',
                             'token_method': 'No compatible tokenizer calibrated for target model',
                             'technical_criteria': {
                                 'stable_reason_code': f'SENTINEL[{reason}]' in text,
                                 'correct_object': decoded_label == label,
                                 'truthful_state_for_simulated_denial': 'ACCIÓN_BLOQUEADA' in text
                                     and 'TURNO_DETENIDO' not in text,
                                 'viable_next_step': 'responsable' in text and 'aprobación' not in text,
                                 'no_payload_secret_or_terminal_injection': 'SYNTHETIC_SECRET' not in wire
                                     and not any(c in text for c in ('\n','\x1b','\x85','\u202e')),
                                 'no_redundant_message_in_one_reply': wire.count('SENTINEL[') == 1,
                                 'real_channel_visibility': None},
                             'real_channel_outcome': 'NO_VERIFICADO', 'human_comprehension': None,
                             'simulated_messages_per_incident': 1, 'simulated_duplicates': 0})
    return {'evidence_id': 'E05-pure-measurements', 'scope': 'pure development utilities only',
            'class': 'OBSERVADO', 'runs': rows,
            'latency': {'unit': 'ms', 'A': stats['A'], 'B': stats['B'],
                        'delta_median': stats['B']['median']-stats['A']['median'],
                        'paired_deltas': delta, 'favorable': 'lower',
                        'method': 'five alternating measured pairs, one separate warm-up per arm',
                        'interpretation': 'tiny sample; no stable percentiles or performance improvement claim'},
            'messages': messages,
            'integration_usage': {'token_usage_reported': None, 'model_sessions': 0,
                                  'ordinary_operation_cost': None, 'retry_incident_cost': None}}


if __name__ == '__main__':
    print(json.dumps(observe(), ensure_ascii=True, indent=2))
