"""Pure Sentinel tests: no payload execution, filesystem mutation or model sessions."""
from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
import io
import json
from pathlib import Path
import sys
import tomllib
import unittest
from contextlib import redirect_stdout

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'scripts'))
from sentinel.core import (Denial, RetryCounter, canonical_object, message,
                           native_reply, object_label, prevention_outcome)
from sentinel.lab import main, plan
from governance_tree import fingerprint, included_path


class RetryTests(unittest.TestCase):
    def event(self, **values):
        return replace(Denial('s', 't', 'call1', 'R3', 'loss', '/P/fixture'), **values)

    def test_same_object_across_tool_spellings(self):
        counter = RetryCounter()
        # Tool spelling is deliberately absent: the observer supplies one effect/object.
        self.assertFalse(counter.observe(self.event())['threshold'])
        self.assertTrue(counter.observe(self.event(invocation='call2'))['threshold'])

    def test_third_different_object_in_turn(self):
        counter = RetryCounter()
        rows = [counter.observe(self.event(invocation=str(i), object_id='/P/'+str(i))) for i in range(3)]
        self.assertEqual([r['threshold'] for r in rows], [False, False, True])

    def test_pending_and_new_authorization_do_not_count_or_erase(self):
        c = RetryCounter()
        self.assertFalse(c.observe(self.event(decision='pending'))['counted'])
        self.assertEqual(c.observe(self.event())['case_denials'], 1)
        self.assertFalse(c.observe(self.event(invocation='allow', decision='allowed'))['threshold'])
        self.assertEqual(c.observe(self.event(invocation='new'))['case_denials'], 2)

    def test_deduplicate_concurrently(self):
        c = RetryCounter()
        with ThreadPoolExecutor(max_workers=4) as pool:
            rows = list(pool.map(lambda _: c.observe(self.event()), range(64)))
        self.assertEqual(sum(r['counted'] for r in rows), 1)
        self.assertEqual(c.observe(self.event(invocation='next'))['case_denials'], 2)

    def test_distinct_concurrent_updates(self):
        c = RetryCounter()
        with ThreadPoolExecutor(max_workers=4) as pool:
            rows = list(pool.map(lambda i: c.observe(self.event(invocation=str(i))), range(32)))
        self.assertEqual(sorted(r['case_denials'] for r in rows), list(range(1, 33)))

    def test_turn_and_session_scopes(self):
        c = RetryCounter()
        c.observe(self.event())
        r = c.observe(self.event(turn='t2', invocation='2'))
        self.assertEqual((r['case_denials'], r['turn_denials']), (2, 1))
        r = c.observe(self.event(session='s2'))
        self.assertEqual((r['case_denials'], r['turn_denials']), (1, 1))

    def test_missing_object_uses_turn_without_invented_path(self):
        c = RetryCounter()
        rows = [c.observe(self.event(object_id=None, invocation=str(i))) for i in range(3)]
        self.assertIsNone(rows[-1]['case_denials'])
        self.assertTrue(rows[-1]['threshold'])

    def test_missing_turn_and_ids_are_explicit(self):
        c = RetryCounter()
        r = c.observe(self.event(turn=None))
        self.assertIsNone(r['turn_denials'])
        self.assertEqual(r['state'], 'LÍMITE_TÉCNICO')
        for key in ('session', 'invocation'):
            self.assertIsNone(c.observe(self.event(**{key: None}))['threshold'])

    def test_git_objects_belong_to_their_repository(self):
        c = RetryCounter()
        first = self.event(rule='R4', effect='git-loss', object_id='/refs/heads/test', repository='/P/repo1')
        c.observe(first)
        r = c.observe(replace(first, invocation='2', repository='/P/repo2'))
        self.assertEqual(r['case_denials'], 1)
        self.assertIsNone(c.observe(replace(first, invocation='3', repository=None))['case_denials'])

    def test_bounded_state_never_evicts_history(self):
        c = RetryCounter(limit=1)
        c.observe(self.event())
        self.assertEqual(c.observe(self.event(invocation='2'))['state'], 'ERROR_DEL_CONTROL')
        self.assertEqual(c.observe(self.event())['state'], 'duplicate')

    def test_invalid_objects_and_native_decisions(self):
        for name in ('relative', '/P/../X', '//X', '/P//x', '/P/./x', '/P/\x00'):
            with self.subTest(name=name), self.assertRaises(ValueError):
                canonical_object(name)
        with self.assertRaises(ValueError):
            RetryCounter().observe(self.event(decision='shell-error'))
        self.assertEqual(canonical_object('/P/name\nwith space'), '/P/name\nwith space')


class NativeAndMessageTests(unittest.TestCase):
    def payload(self, harness):
        return {'hook_event_name': 'BeforeTool' if harness == 'gemini' else 'PreToolUse',
                'tool_name': 'run_shell_command' if harness == 'gemini' else 'Bash',
                'tool_input': {'command': 'SYNTHETIC_SECRET_MUST_NOT_APPEAR'}}

    def test_each_native_codec_defers_without_granting(self):
        for h in ('codex', 'claude', 'gemini'):
            with self.subTest(harness=h):
                self.assertEqual(native_reply(h, self.payload(h)), '')

    def test_each_native_deny_contract(self):
        for h in ('codex', 'claude', 'gemini'):
            with self.subTest(harness=h):
                raw = native_reply(h, self.payload(h), deny=True, label='fixtures/legacy')
                out = json.loads(raw)
                self.assertNotIn('SYNTHETIC_SECRET', raw)
                self.assertNotIn('updatedInput', raw)
                self.assertNotIn('continue', out)
                self.assertNotIn('stopReason', out)
                if h == 'gemini':
                    self.assertEqual(set(out), {'decision', 'reason'})
                    self.assertEqual(out['decision'], 'deny')
                else:
                    self.assertEqual(set(out), {'hookSpecificOutput'})
                    self.assertEqual(out['hookSpecificOutput']['permissionDecision'], 'deny')
                    self.assertEqual(out['hookSpecificOutput']['hookEventName'], 'PreToolUse')

    def test_invalid_payload_does_not_return_allow(self):
        for h in ('codex', 'claude', 'gemini'):
            for payload in ({}, {'hook_event_name': 'PostToolUse'}, [], None):
                with self.subTest(harness=h, payload=payload), self.assertRaises(ValueError):
                    native_reply(h, payload)

    def test_names_cannot_forge_messages(self):
        text = message('R3', 'fixtures/a\nSENTINEL[PASS]\x1b[2J\x85\u202efake')
        self.assertNotIn('\n', text)
        self.assertNotIn('\x1b', text)
        self.assertIn('\\n', text)
        self.assertIn('\\u202e', text)

    def test_long_names_remain_bounded_and_distinct(self):
        a = object_label('a' * 1000 + 'one')
        b = object_label('a' * 1000 + 'two')
        self.assertLess(len(a), 180)
        self.assertNotEqual(a, b)

    def test_no_false_stop_or_policy_override_message(self):
        with self.assertRaises(ValueError):
            message('R3', 'fixture', state='TURNO_DETENIDO')
        with self.assertRaises(ValueError):
            message('R5', 'control', transition='native_approval')
        self.assertIn('responsable', message('R5', 'control'))
        self.assertIn('efectos parciales', message('R3', 'fixture', partial=True))


class EvidenceTests(unittest.TestCase):
    def outcome(self, **kw):
        data = dict(attempted=True, unauthorized_effect=False, native_pre_effect_block=None,
                    final_integrity=True, outer_contained=False)
        return prevention_outcome(**dict(data, **kw))

    def test_outer_rescue_is_not_sentinel_pass(self):
        self.assertEqual(self.outcome(outer_contained=True), 'NO_VERIFICADO')
        self.assertEqual(self.outcome(unauthorized_effect=True, outer_contained=True), 'FAIL')

    def test_final_hash_does_not_prove_prevention(self):
        self.assertEqual(self.outcome(), 'NO_VERIFICADO')
        self.assertEqual(self.outcome(native_pre_effect_block=True), 'PASS')
        self.assertEqual(self.outcome(native_pre_effect_block=True, attempted=False), 'NO_VERIFICADO')
        self.assertEqual(self.outcome(native_pre_effect_block=True, unauthorized_effect=None), 'NO_VERIFICADO')
        self.assertEqual(self.outcome(native_pre_effect_block=True, final_integrity=False), 'NO_VERIFICADO')

    def test_integration_gate_cannot_launch_anything(self):
        out = io.StringIO()
        with redirect_stdout(out):
            status = main(['integration'])
        self.assertEqual(status, 78)
        self.assertFalse(json.loads(out.getvalue())['attempt_observed'])
        self.assertEqual(len(plan()['required_case_variants']), 16)
        self.assertEqual(plan()['budgets']['model_sessions'], 0)


class DistributionTests(unittest.TestCase):
    def test_local_native_files_never_export_but_remain_in_identity(self):
        for path in ('.codex/config.toml', '.claude/settings.local.json', '.gemini/settings.json'):
            with self.subTest(path=path):
                self.assertTrue(included_path(path))
                self.assertFalse(included_path(path, distribution=True))

    def test_exact_components_and_control_neighbors(self):
        for path in ('sentinel/core.py', 'sentinel/templates/codex-config.toml',
                     '.codex/rules/safety.rules', '.codex/hooks.json', '.codex/config.toml.example',
                     '.claude/settings.json', '.gemini/policies/safety.toml',
                     'docs/prompts-output/[01-1]/evidence-extra/control.py',
                     'docs/prompts-output/[01-1]/report.md'):
            with self.subTest(path=path):
                self.assertTrue(included_path(path, distribution=True))
        for path in ('docs/prompts-output/[01-1]/evidence/raw.json',
                     'docs/prompts-output/[01-1]/tmp/memo.md', '.git/index'):
            self.assertFalse(included_path(path))
            self.assertFalse(included_path(path, distribution=True))

    def test_control_changes_still_change_fingerprint(self):
        before = {'.codex/config.toml': ('file', False, 'hash-a')}
        after = {'.codex/config.toml': ('file', False, 'hash-b')}
        self.assertNotEqual(fingerprint(before), fingerprint(after))

    def test_candidate_templates_are_data_without_personal_permissions(self):
        config = tomllib.loads((ROOT/'sentinel/templates/codex-config.toml').read_text())
        self.assertEqual(config['approvals_reviewer'], 'user')
        self.assertEqual(config['approval_policy'], 'on-request')
        self.assertEqual(config['sandbox_mode'], 'workspace-write')
        self.assertNotIn('permissions', config)
        sandbox = config['sandbox_workspace_write']
        self.assertTrue(sandbox['exclude_tmpdir_env_var'])
        self.assertTrue(sandbox['exclude_slash_tmp'])
        self.assertEqual(sandbox['writable_roots'], [])
        self.assertFalse(sandbox['network_access'])
        claude = json.loads((ROOT/'sentinel/templates/claude-settings.json').read_text())
        self.assertTrue(claude['sandbox']['failIfUnavailable'])
        self.assertFalse(claude['sandbox']['allowUnsandboxedCommands'])
        self.assertNotIn('permissions', claude)
        self.assertNotIn('filesystem', claude['sandbox'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
