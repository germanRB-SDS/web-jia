# Governance changes

See [the detailed change log](governance-change-log.md) and [capability ledger](capability-registry.md).

REL-2026-09-10-02 adds optional closed MCP tooling; provider activation stays quarantined.
